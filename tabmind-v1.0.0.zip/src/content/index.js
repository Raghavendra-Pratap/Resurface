(function(){"use strict";function G(e,t){return{type:e,payload:t}}async function w(e,t){return chrome.runtime.sendMessage(G(e,t))}function P(e){try{const{hostname:t}=new URL(e);return t.replace("www.","")}catch{return""}}function j(e){if(!e)return null;try{const t=new URL(e);return t.hostname.includes("google.")||t.hostname.includes("bing.")||t.hostname.includes("duckduckgo.")?t.searchParams.get("q"):t.hostname.includes("yahoo.")?t.searchParams.get("p"):null}catch{return null}}function d(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}async function V(){const e=window.location.href,t=document.title||e,n=document.referrer||null,a=j(n),o=await z(e);return{url:e,title:t,favicon:o.data,faviconType:o.type,referrerUrl:n,referrerQuery:a}}async function z(e){const t=document.querySelectorAll('link[rel="icon"], link[rel="shortcut icon"], link[rel="apple-touch-icon"]');let n=null;for(const a of t)if(a.href&&(n=a.href,a.rel.includes("apple-touch-icon")))break;n||(n=`https://www.google.com/s2/favicons?domain=${P(e)}&sz=64`);try{const o=await(await fetch(n)).blob();return new Promise(c=>{const s=new FileReader;s.onloadend=()=>{c({data:s.result,type:"base64"})},s.onerror=()=>{c({data:n,type:"url"})},s.readAsDataURL(o)})}catch{return{data:n,type:"url"}}}let f=null,$=null,q=5e3,h=null;function W(e){return new Promise(t=>{x(),h=t,q=e.autoSaveDelay;const n=document.createElement("div");n.id="tabmind-toast-container",n.innerHTML=B(e),document.body.appendChild(n),f=n,K(n,e),R(),n.addEventListener("click",a=>{a.target===n&&M()})})}function x(){$&&(clearTimeout($),$=null),f&&(f.remove(),f=null),h=null}function B(e){const{pageData:t,suggestedTopics:n,intents:a}=e;return`
    <div class="tabmind-toast">
      <div class="tabmind-toast-header">
        <div class="tabmind-toast-icon">
          <svg viewBox="0 0 24 24">
            <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
          </svg>
        </div>
        <div>
          <div class="tabmind-toast-header-text">Add to TabMind</div>
          <div class="tabmind-toast-header-subtitle">${e.autoSaveDelay>0?`Auto-saves in ${e.autoSaveDelay/1e3} seconds`:"Manual save only"}</div>
        </div>
      </div>
      
      <div class="tabmind-toast-body">
        <div class="tabmind-field">
          <label class="tabmind-label">Title</label>
          <input 
            id="tabmind-title" 
            type="text" 
            class="tabmind-input" 
            value="${d(t.title)}"
          >
        </div>
        
        <div class="tabmind-field">
          <label class="tabmind-label">Topics</label>
          <div class="tabmind-tags" id="tabmind-topics">
            ${n.map(o=>F(o)).join("")}
            <button class="tabmind-tag-add" id="tabmind-add-topic">+ Add</button>
          </div>
        </div>
        
        <div class="tabmind-field">
          <label class="tabmind-label">Intent (optional)</label>
          <select id="tabmind-intent" class="tabmind-select">
            <option value="">Select intent...</option>
            ${a.map(o=>`
              <option value="${o.id}">${o.emoji} ${d(o.name)}</option>
            `).join("")}
          </select>
        </div>
      </div>
      
      <div class="tabmind-toast-footer">
        <button id="tabmind-cancel" class="tabmind-btn tabmind-btn-secondary">Cancel</button>
        <button id="tabmind-save" class="tabmind-btn tabmind-btn-primary">Save</button>
      </div>
      
      ${e.autoSaveDelay>0?`<div class="tabmind-timer-bar" id="tabmind-timer" style="animation-duration: ${e.autoSaveDelay}ms"></div>`:""}
    </div>
  `}function F(e){return`
    <span class="tabmind-tag" data-topic-id="${e.id}" style="background: ${Q(e.color,.15)}; color: ${e.color};">
      ${d(e.name)}
      <span class="tabmind-tag-remove" data-topic-id="${e.id}">×</span>
    </span>
  `}function K(e,t){const n=e.querySelector("#tabmind-save"),a=e.querySelector("#tabmind-cancel"),o=e.querySelector("#tabmind-title"),c=e.querySelector("#tabmind-topics"),s=e.querySelector("#tabmind-add-topic"),m=e.querySelector("#tabmind-timer"),u=new Set(t.suggestedTopics.map(l=>l.id));n==null||n.addEventListener("click",()=>M()),a==null||a.addEventListener("click",()=>J()),document.addEventListener("keydown",p),o==null||o.addEventListener("focus",()=>i()),o==null||o.addEventListener("blur",()=>g()),c==null||c.addEventListener("click",l=>{var v;const r=l.target;if(r.classList.contains("tabmind-tag-remove")){const y=r.dataset.topicId;y&&(u.delete(y),(v=r.parentElement)==null||v.remove())}}),s==null||s.addEventListener("click",()=>{const l=prompt("Enter topic name:");if(l&&l.trim()){const r=`temp-${Date.now()}`;u.add(r);const v=document.createElement("span");v.className="tabmind-tag",v.dataset.topicId=r,v.dataset.topicName=l.trim(),v.style.background="rgba(99, 102, 241, 0.15)",v.style.color="#818cf8",v.innerHTML=`
        ${d(l.trim())}
        <span class="tabmind-tag-remove" data-topic-id="${r}">×</span>
      `,s.before(v)}}),e.collectData=()=>{const l=(o==null?void 0:o.value)||t.pageData.title,r=e.querySelector("#tabmind-intent"),v=(r==null?void 0:r.value)||"",y=[];return e.querySelectorAll(".tabmind-tag[data-topic-id]").forEach(b=>{const T=b.dataset.topicId;T&&y.push(T)}),{title:l,topicIds:y,intentIds:v?[v]:[]}};function i(){m==null||m.classList.add("tabmind-paused"),$&&(clearTimeout($),$=null)}function g(){m==null||m.classList.remove("tabmind-paused"),R()}function p(l){(l.key==="Escape"||l.key==="Enter"&&(l.metaKey||l.ctrlKey))&&M()}}function M(){if(console.log("TabMind Toast: save() called"),!f||!h){console.log("TabMind Toast: No toast or resolve promise",{currentToast:!!f,resolvePromise:!!h});return}const e=f.collectData,t=e();console.log("TabMind Toast: Collected data:",t);const n=f.querySelector(".tabmind-toast");n==null||n.classList.add("tabmind-closing"),setTimeout(()=>{console.log("TabMind Toast: Resolving promise with result"),h==null||h(t),x()},200)}function J(){if(!h)return;const e=f==null?void 0:f.querySelector(".tabmind-toast");e==null||e.classList.add("tabmind-closing"),setTimeout(()=>{h==null||h(null),x()},200)}function R(){$&&clearTimeout($),$=setTimeout(()=>{M()},q)}function Q(e,t){const n=parseInt(e.slice(1,3),16),a=parseInt(e.slice(3,5),16),o=parseInt(e.slice(5,7),16);return`rgba(${n}, ${a}, ${o}, ${t})`}let L=null,S=null;function O(e){if(D(),e.length===0)return;const t=document.createElement("div");t.id="tabmind-dropdown",t.innerHTML=Y(e),t.style.top="80px",t.style.right="20px",t.style.position="fixed",document.body.appendChild(t),L=t,t.querySelectorAll(".tabmind-dropdown-item").forEach(n=>{n.addEventListener("click",()=>{const a=n.dataset.url;a&&(window.location.href=a)})}),setTimeout(()=>{S=n=>{L&&!L.contains(n.target)&&D()},document.addEventListener("click",S)},100),setTimeout(()=>{D()},1e4)}function D(){L&&(L.remove(),L=null),S&&(document.removeEventListener("click",S),S=null)}function Y(e){return`
    <div class="tabmind-dropdown-header">
      <svg viewBox="0 0 24 24">
        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
      </svg>
      <span><strong>${e.length} saved page${e.length>1?"s":""}</strong> match your search</span>
    </div>
    <div class="tabmind-dropdown-items">
      ${e.map(t=>X(t)).join("")}
    </div>
  `}function X(e){const t=e.favicon?`<img src="${d(e.favicon)}" alt="" onerror="this.style.display='none';this.parentElement.textContent='${e.domain[0].toUpperCase()}'">`:e.domain[0].toUpperCase();return`
    <div class="tabmind-dropdown-item" data-url="${d(e.url)}">
      <div class="tabmind-dropdown-favicon">
        ${t}
      </div>
      <div class="tabmind-dropdown-info">
        <div class="tabmind-dropdown-title">${d(e.title)}</div>
        <div class="tabmind-dropdown-meta">
          <span>${d(e.domain)}</span>
          <span>•</span>
          <span>${e.savedAt}</span>
        </div>
      </div>
      <div class="tabmind-dropdown-tags">
        ${e.topics.slice(0,2).map(n=>`
          <span class="tabmind-mini-tag topic" style="background: ${Z(n.color,.15)}; color: ${n.color};">
            ${d(n.name)}
          </span>
        `).join("")}
        ${e.intents.slice(0,1).map(n=>`
          <span class="tabmind-mini-tag intent">${n.emoji}</span>
        `).join("")}
      </div>
    </div>
  `}function Z(e,t){const n=parseInt(e.slice(1,3),16),a=parseInt(e.slice(3,5),16),o=parseInt(e.slice(5,7),16);return`rgba(${n}, ${a}, ${o}, ${t})`}let H=null,_=[];function ee(e){I(),_=e;const t=document.createElement("div");t.id="tabmind-search-modal",t.innerHTML=te(e),document.body.appendChild(t),H=t,ae(t);const n=t.querySelector("#tabmind-search-input");setTimeout(()=>n==null?void 0:n.focus(),50)}function I(){H&&(H.remove(),H=null),_=[]}function te(e){return`
    <div class="tabmind-search-overlay" id="tabmind-search-overlay">
      <div class="tabmind-search-container">
        <div class="tabmind-search-header">
          <div class="tabmind-search-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"/>
              <path d="m21 21-4.35-4.35"/>
            </svg>
          </div>
          <input 
            type="text" 
            id="tabmind-search-input"
            class="tabmind-search-input" 
            placeholder="Search your saved tabs..."
            autocomplete="off"
            spellcheck="false"
          >
          <div class="tabmind-search-shortcut">
            <kbd>esc</kbd> to close
          </div>
        </div>
        
        <div class="tabmind-search-results" id="tabmind-search-results">
          ${N(e)}
        </div>
        
        <div class="tabmind-search-footer">
          <div class="tabmind-search-footer-left">
            <span class="tabmind-result-count" id="tabmind-result-count">${e.length} saved pages</span>
          </div>
          <div class="tabmind-search-footer-right">
            <span class="tabmind-footer-hint">
              <kbd>↑</kbd><kbd>↓</kbd> navigate
              <kbd>↵</kbd> open
            </span>
          </div>
        </div>
      </div>
    </div>
  `}function N(e){return e.length===0?`
      <div class="tabmind-search-empty">
        <div class="tabmind-search-empty-icon">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
          </svg>
        </div>
        <div class="tabmind-search-empty-text">No saved pages found</div>
        <div class="tabmind-search-empty-hint">Press <kbd>⌘+Shift+S</kbd> to save pages</div>
      </div>
    `:e.map((t,n)=>ne(t,n)).join("")}function ne(e,t){const n=e.favicon?`<img src="${d(e.favicon)}" alt="" onerror="this.style.display='none';this.parentElement.textContent='${e.domain[0].toUpperCase()}'">`:e.domain[0].toUpperCase();return`
    <div class="tabmind-search-item ${t===0?"selected":""}" data-url="${d(e.url)}" data-index="${t}">
      <div class="tabmind-search-item-favicon">
        ${n}
      </div>
      <div class="tabmind-search-item-content">
        <div class="tabmind-search-item-title">${d(e.title)}</div>
        <div class="tabmind-search-item-meta">
          <span class="tabmind-search-item-domain">${d(e.domain)}</span>
          <span class="tabmind-search-item-separator">•</span>
          <span class="tabmind-search-item-time">${e.savedAt}</span>
        </div>
      </div>
      <div class="tabmind-search-item-tags">
        ${e.topics.slice(0,2).map(a=>`
          <span class="tabmind-search-tag topic" style="background: ${se(a.color,.15)}; color: ${a.color};">
            ${d(a.name)}
          </span>
        `).join("")}
        ${e.intents.slice(0,1).map(a=>`
          <span class="tabmind-search-tag intent">${a.emoji}</span>
        `).join("")}
      </div>
    </div>
  `}function ae(e){const t=e.querySelector("#tabmind-search-overlay"),n=e.querySelector("#tabmind-search-input"),a=e.querySelector("#tabmind-search-results");let o=0,c=null;t==null||t.addEventListener("click",u=>{u.target===t&&I()}),document.addEventListener("keydown",s),n==null||n.addEventListener("input",()=>{c&&clearTimeout(c),c=setTimeout(async()=>{const u=n.value.trim();if(u.length===0)m(_);else try{const i=await w("SEARCH_ITEMS",{query:u}),g=await w("GET_ALL_TOPICS"),p=await w("GET_ALL_INTENTS"),l=i.map(r=>({id:r.id,title:r.title,url:r.url,favicon:r.favicon,faviconType:r.faviconType,domain:new URL(r.url).hostname.replace("www.",""),savedAt:oe(r.savedAt),topics:g.filter(v=>r.topicIds.includes(v.id)),intents:p.filter(v=>r.intentIds.includes(v.id))}));m(l)}catch(i){console.error("Search error:",i)}},150)}),a==null||a.addEventListener("click",u=>{const i=u.target.closest(".tabmind-search-item");if(i){const g=i.dataset.url;g&&(window.location.href=g,I())}});function s(u){var g,p,l,r,v,y;const i=e.querySelectorAll(".tabmind-search-item");switch(u.key){case"Escape":I(),document.removeEventListener("keydown",s);break;case"ArrowDown":u.preventDefault(),i.length>0&&((g=i[o])==null||g.classList.remove("selected"),o=(o+1)%i.length,(p=i[o])==null||p.classList.add("selected"),(l=i[o])==null||l.scrollIntoView({block:"nearest"}));break;case"ArrowUp":u.preventDefault(),i.length>0&&((r=i[o])==null||r.classList.remove("selected"),o=(o-1+i.length)%i.length,(v=i[o])==null||v.classList.add("selected"),(y=i[o])==null||y.scrollIntoView({block:"nearest"}));break;case"Enter":const b=i[o];if(b){const T=b.dataset.url;T&&(window.location.href=T,I())}document.removeEventListener("keydown",s);break}}function m(u){if(a){a.innerHTML=N(u),o=0;const i=e.querySelector("#tabmind-result-count");i&&(i.textContent=`${u.length} saved page${u.length!==1?"s":""}`)}}}function oe(e){const t=Math.floor((Date.now()-e)/1e3);if(t<60)return"Just now";const n=Math.floor(t/60);if(n<60)return`${n}m ago`;const a=Math.floor(n/60);if(a<24)return`${a}h ago`;const o=Math.floor(a/24);if(o<7)return`${o}d ago`;const c=Math.floor(o/7);if(c<4)return`${c}w ago`;const s=Math.floor(o/30);return s<12?`${s}mo ago`:`${Math.floor(o/365)}y ago`}function se(e,t){const n=parseInt(e.slice(1,3),16),a=parseInt(e.slice(3,5),16),o=parseInt(e.slice(5,7),16);return`rgba(${n}, ${a}, ${o}, ${t})`}let E=null,k=!1;function ie(e,t){if(C(),e.length===0)return;const n=document.createElement("div");n.id="tabmind-google-overlay",n.innerHTML=re(e,t),document.body.appendChild(n),E=n,ce(n,t),requestAnimationFrame(()=>{n.classList.add("visible")})}function C(){E&&(E.classList.remove("visible"),setTimeout(()=>{E==null||E.remove(),E=null},200))}function re(e,t){return`
    <div class="tabmind-google-overlay-container ${k?"minimized":""}">
      <div class="tabmind-google-overlay-header">
        <div class="tabmind-google-overlay-header-left">
          <div class="tabmind-google-overlay-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
            </svg>
          </div>
          <span class="tabmind-google-overlay-title">
            <strong>${e.length} saved page${e.length>1?"s":""}</strong> match your search
          </span>
        </div>
        <div class="tabmind-google-overlay-header-right">
          <button class="tabmind-google-overlay-toggle" id="tabmind-toggle-overlay" title="${k?"Expand":"Minimize"}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              ${k?'<polyline points="6 9 12 15 18 9"/>':'<polyline points="18 15 12 9 6 15"/>'}
            </svg>
          </button>
          <button class="tabmind-google-overlay-close" id="tabmind-close-overlay" title="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
      </div>
      
      <div class="tabmind-google-overlay-body" id="tabmind-overlay-body">
        <div class="tabmind-google-overlay-search">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/>
            <path d="m21 21-4.35-4.35"/>
          </svg>
          <input 
            type="text" 
            id="tabmind-google-search-input"
            placeholder="Search your saved tabs..."
            value="${d(t)}"
            autocomplete="off"
            spellcheck="false"
          >
        </div>
        
        <div class="tabmind-google-overlay-items" id="tabmind-overlay-items">
          ${U(e)}
        </div>
      </div>
      
      <div class="tabmind-google-overlay-footer">
        <span class="tabmind-google-overlay-hint">
          <kbd>⌘</kbd><kbd>⇧</kbd><kbd>F</kbd> to search all
        </span>
        <a href="${chrome.runtime.getURL("src/dashboard/index.html")}" class="tabmind-google-overlay-dashboard" target="_blank">
          Open Dashboard →
        </a>
      </div>
    </div>
  `}function U(e){return e.map((t,n)=>`
    <div class="tabmind-google-overlay-item" data-url="${d(t.url)}" data-index="${n}">
      <div class="tabmind-google-overlay-item-favicon">
        ${t.favicon?`<img src="${d(t.favicon)}" alt="" onerror="this.style.display='none';this.parentElement.textContent='${t.domain[0].toUpperCase()}'">`:t.domain[0].toUpperCase()}
      </div>
      <div class="tabmind-google-overlay-item-info">
        <div class="tabmind-google-overlay-item-row1">
          <div class="tabmind-google-overlay-item-title">${d(t.title)}</div>
          <div class="tabmind-google-overlay-item-meta">
            <span>${d(t.domain)}</span>
            <span class="tabmind-separator">•</span>
            <span>${t.savedAt}</span>
          </div>
        </div>
        ${t.topics.length>0?`
          <div class="tabmind-google-overlay-item-row2">
            ${t.topics.slice(0,3).map(a=>`
              <span class="tabmind-overlay-tag" style="background: ${de(a.color,.15)}; color: ${a.color};">
                ${d(a.name)}
              </span>
            `).join("")}
          </div>
        `:""}
      </div>
    </div>
  `).join("")}function ce(e,t){const n=e.querySelector("#tabmind-close-overlay"),a=e.querySelector("#tabmind-toggle-overlay"),o=e.querySelector("#tabmind-google-search-input"),c=e.querySelector("#tabmind-overlay-items"),s=e.querySelector(".tabmind-google-overlay-container");let m=null;n==null||n.addEventListener("click",()=>{C(),document.removeEventListener("keydown",i),document.removeEventListener("click",u)});function u(p){s&&!s.contains(p.target)&&(C(),document.removeEventListener("keydown",i),document.removeEventListener("click",u))}function i(p){p.key==="Escape"&&(C(),document.removeEventListener("keydown",i),document.removeEventListener("click",u))}setTimeout(()=>{document.addEventListener("keydown",i),document.addEventListener("click",u)},100),a==null||a.addEventListener("click",()=>{k=!k,s==null||s.classList.toggle("minimized",k),a&&(a.innerHTML=`
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          ${k?'<polyline points="6 9 12 15 18 9"/>':'<polyline points="18 15 12 9 6 15"/>'}
        </svg>
      `,a.title=k?"Expand":"Minimize")}),o==null||o.addEventListener("input",()=>{m&&clearTimeout(m),m=setTimeout(async()=>{const p=o.value.trim();p.length===0?await g(t):await g(p)},150)}),c==null||c.addEventListener("click",p=>{const l=p.target.closest(".tabmind-google-overlay-item");if(l){const r=l.dataset.url;r&&window.open(r,"_blank")}});async function g(p){try{const l=await w("SEARCH_ITEMS",{query:p}),r=await w("GET_ALL_TOPICS"),v=await w("GET_ALL_INTENTS"),y=l.slice(0,5).map(b=>({id:b.id,title:b.title,url:b.url,favicon:b.favicon,faviconType:b.faviconType,domain:new URL(b.url).hostname.replace("www.",""),savedAt:le(b.savedAt),topics:r.filter(T=>b.topicIds.includes(T.id)),intents:v.filter(T=>b.intentIds.includes(T.id))}));c&&(y.length===0?c.innerHTML=`
            <div class="tabmind-google-overlay-empty">
              No saved pages match "${d(p)}"
            </div>
          `:c.innerHTML=U(y))}catch(l){console.error("Error updating results:",l)}}}function le(e){const t=Math.floor((Date.now()-e)/1e3);if(t<60)return"Just now";const n=Math.floor(t/60);if(n<60)return`${n}m ago`;const a=Math.floor(n/60);if(a<24)return`${a}h ago`;const o=Math.floor(a/24);if(o<7)return`${o}d ago`;const c=Math.floor(o/7);if(c<4)return`${c}w ago`;const s=Math.floor(o/30);return s<12?`${s}mo ago`:`${Math.floor(o/365)}y ago`}function de(e,t){const n=parseInt(e.slice(1,3),16),a=parseInt(e.slice(3,5),16),o=parseInt(e.slice(5,7),16);return`rgba(${n}, ${a}, ${o}, ${t})`}chrome.runtime.onMessage.addListener((e,t,n)=>e.type==="PING"?(n({pong:!0}),!0):(ue(e).then(n).catch(a=>{console.error("TabMind content script error:",a),n({error:a.message})}),!0));async function ue(e){switch(e.type){case"EXTRACT_PAGE":return V();case"SHOW_TOAST":return pe(e.payload),{received:!0};case"SHOW_ALREADY_SAVED":return be(e.payload);case"SHOW_CONFIRMATION":return ge(e.payload);case"SHOW_DROPDOWN":return fe(e.payload);case"HIDE_DROPDOWN":D();return;case"SHOW_GOOGLE_HINT":return he(e.payload);case"SHOW_SEARCH_MODAL":return me(e.payload);case"SHOW_GOOGLE_OVERLAY":return ve(e.payload);default:console.warn("TabMind: Unknown message type:",e.type)}}async function ve(e){ie(e.items,e.query)}async function me(e){ee(e.items)}async function pe(e){console.log("TabMind: Showing toast with data:",e);try{const t=await W(e);if(console.log("TabMind: Toast result:",t),t){console.log("TabMind: User saved, sending SAVE_ITEM to background...");const n={pageData:e.pageData,toastResult:t,siblingTabUrls:e.siblingTabUrls};console.log("TabMind: SAVE_ITEM payload:",n);const a=await w("SAVE_ITEM",n);console.log("TabMind: Save successful! Saved item:",a),A("Saved to TabMind","success")}else console.log("TabMind: User cancelled (result was null/undefined)"),A("Not saved","muted")}catch(t){console.error("TabMind: Error in handleShowToast:",t),A("Error saving","muted")}}async function be(e){A("Already in your library","info")}async function ge(e){A(e.message,"success")}async function fe(e){O(e.items)}async function he(e){if(document.getElementById("tabmind-google-hint"))return;const t=document.createElement("div");t.id="tabmind-google-hint",t.className="tabmind-google-hint",t.innerHTML=`
    <div class="tabmind-google-hint-icon">
      <svg viewBox="0 0 24 24">
        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
      </svg>
    </div>
    <div class="tabmind-google-hint-text">
      <strong>${e.count}</strong> saved page${e.count>1?"s":""} match "${d(e.query)}"
    </div>
  `,document.body.appendChild(t),t.addEventListener("click",async()=>{const n=await w("SEARCH_ITEMS",{query:e.query});if(n&&n.length>0){const a=await w("GET_ALL_TOPICS"),o=await w("GET_ALL_INTENTS"),c=n.map(s=>({id:s.id,title:s.title,url:s.url,favicon:s.favicon,faviconType:s.faviconType,domain:new URL(s.url).hostname.replace("www.",""),savedAt:ye(s.savedAt),topics:a.filter(m=>s.topicIds.includes(m.id)),intents:o.filter(m=>s.intentIds.includes(m.id))}));O(c)}t.remove()}),setTimeout(()=>{t.remove()},8e3)}function A(e,t){const n=document.querySelector(".tabmind-mini-toast");n&&n.remove();const a=document.createElement("div");a.className="tabmind-mini-toast";const o=t==="success"?'<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>':t==="info"?'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>':'<svg viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg>';a.innerHTML=`
    <div class="tabmind-mini-toast-icon ${t}">
      ${o}
    </div>
    <div class="tabmind-mini-toast-text">${d(e)}</div>
  `,document.body.appendChild(a),setTimeout(()=>{a.classList.add("tabmind-closing"),setTimeout(()=>a.remove(),200)},3e3)}function ye(e){const t=Math.floor((Date.now()-e)/1e3);if(t<60)return"Just now";const n=Math.floor(t/60);if(n<60)return`${n}m ago`;const a=Math.floor(n/60);if(a<24)return`${a}h ago`;const o=Math.floor(a/24);if(o<7)return`${o}d ago`;const c=Math.floor(o/7);if(c<4)return`${c}w ago`;const s=Math.floor(o/30);return s<12?`${s}mo ago`:`${Math.floor(o/365)}y ago`}console.log("TabMind content script loaded")})();
