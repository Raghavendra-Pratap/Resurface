import{s as v}from"../../messages.js";let w=[],y=[],I=[],d=-1,h=[],m=[];document.addEventListener("DOMContentLoaded",async()=>{await x(),A(),z(),$(),S()});async function $(){try{const t=await chrome.commands.getAll(),e=document.querySelector(".newtab-hints");if(!e)return;const a=t.find(n=>n.name==="save-tab"),r=t.find(n=>n.name==="resurface"),c=(a==null?void 0:a.shortcut)||"Not set",s=(r==null?void 0:r.shortcut)||"Not set";e.innerHTML=`
      <span class="newtab-hint-item" title="Click to customize">
        ${g(c)} Save current tab
      </span>
      <span class="newtab-hint-item" title="Click to customize">
        ${g(s)} Search saved tabs
      </span>
      <a href="chrome://extensions/shortcuts" class="newtab-hint-customize" id="customize-shortcuts">
        Customize shortcuts
      </a>
    `;const l=document.getElementById("customize-shortcuts");l==null||l.addEventListener("click",n=>{n.preventDefault(),M()})}catch(t){console.error("Error fetching shortcuts:",t)}}function g(t){return!t||t==="Not set"?'<span class="newtab-shortcut-notset">Not set</span>':t.replace("Command","⌘").replace("Cmd","⌘").replace("MacCtrl","⌃").replace("Ctrl","⌃").replace("Alt","⌥").replace("Shift","⇧").split("+").map(a=>`<kbd>${a.trim()}</kbd>`).join("")}function M(){var a,r,c;const t=document.createElement("div");t.className="newtab-shortcut-modal",t.innerHTML=`
    <div class="newtab-shortcut-modal-content">
      <div class="newtab-shortcut-modal-header">
        <h3>Customize Keyboard Shortcuts</h3>
        <button class="newtab-shortcut-modal-close" id="close-modal">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
      </div>
      <div class="newtab-shortcut-modal-body">
        <p>To customize TabMind's keyboard shortcuts:</p>
        <ol>
          <li>Open Chrome and go to <code>chrome://extensions</code></li>
          <li>Click the <strong>menu icon</strong> (☰) in the top-left</li>
          <li>Select <strong>"Keyboard shortcuts"</strong></li>
          <li>Find <strong>TabMind</strong> and set your preferred shortcuts</li>
        </ol>
        <div class="newtab-shortcut-modal-actions">
          <button class="newtab-btn newtab-btn-secondary" id="copy-url">
            Copy URL
          </button>
          <button class="newtab-btn newtab-btn-primary" id="close-modal-btn">
            Got it
          </button>
        </div>
      </div>
    </div>
  `,document.body.appendChild(t),requestAnimationFrame(()=>t.classList.add("visible"));const e=()=>{t.classList.remove("visible"),setTimeout(()=>t.remove(),200)};(a=t.querySelector("#close-modal"))==null||a.addEventListener("click",e),(r=t.querySelector("#close-modal-btn"))==null||r.addEventListener("click",e),t.addEventListener("click",s=>{s.target===t&&e()}),(c=t.querySelector("#copy-url"))==null||c.addEventListener("click",()=>{navigator.clipboard.writeText("chrome://extensions/shortcuts");const s=t.querySelector("#copy-url");s&&(s.textContent="Copied!",setTimeout(()=>s.textContent="Copy URL",2e3))})}function S(){const t=document.getElementById("search-input");t&&(t.focus(),setTimeout(()=>t.focus(),0),setTimeout(()=>t.focus(),50),setTimeout(()=>t.focus(),100),setTimeout(()=>t.focus(),200),window.addEventListener("focus",()=>{setTimeout(()=>t.focus(),0)}),document.addEventListener("click",e=>{e.target.closest("a, button, input, select, textarea")||t.focus()}))}async function x(){try{w=await v("GET_ALL_ITEMS")||[],y=await v("GET_ALL_TOPICS")||[],I=await v("GET_ALL_INTENTS")||[]}catch(t){console.error("Error loading data:",t)}}function A(){const t=document.getElementById("search-input"),e=document.getElementById("results-tray"),a=document.getElementById("history-tray"),r=document.getElementById("open-dashboard");r.href=chrome.runtime.getURL("src/dashboard/index.html");let c=null;t.addEventListener("input",()=>{c&&clearTimeout(c),c=setTimeout(()=>{const s=t.value.trim();L(s)},100)}),t.addEventListener("keydown",s=>{const l=a.querySelectorAll(".newtab-history-item"),n=e.querySelectorAll(".newtab-result-item"),u=l.length,b=n.length,i=u+b;switch(s.key){case"ArrowDown":s.preventDefault(),i>0&&(d=Math.min(d+1,i-1),T(l,n,u));break;case"ArrowUp":s.preventDefault(),i>0&&(d=Math.max(d-1,-1),T(l,n,u));break;case"Enter":s.preventDefault();const o=t.value.trim();if(C(o)){window.location.href=B(o);return}if(d>=0){if(d<u&&m[d])window.location.href=m[d].url;else if(d>=u){const p=d-u;h[p]&&(window.location.href=h[p].url)}}else o&&(window.location.href=`https://www.google.com/search?q=${encodeURIComponent(o)}`);break;case"Escape":t.value="",L(""),d=-1;break}}),a.addEventListener("click",s=>{const l=s.target.closest(".newtab-history-item");if(l){const n=l.dataset.url;n&&(window.location.href=n)}}),e.addEventListener("click",s=>{const l=s.target.closest(".newtab-result-item");if(l){const n=l.dataset.url;n&&(window.location.href=n)}})}function C(t){return t.includes(" ")?!1:!!(/^https?:\/\//i.test(t)||/^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+/.test(t)||/^(localhost|(\d{1,3}\.){3}\d{1,3})(:\d+)?/.test(t))}function B(t){return/^https?:\/\//i.test(t)?t:`https://${t}`}async function L(t){const e=document.getElementById("results-tray"),a=document.getElementById("results-list"),r=document.getElementById("results-count"),c=document.getElementById("results-header"),s=document.getElementById("history-tray"),l=document.getElementById("history-list"),n=document.getElementById("search-hint");if(d=-1,!t||t.length<1){e.classList.remove("visible"),s.classList.remove("visible"),n.innerHTML="<kbd>↵</kbd> Google",h=[],m=[];return}if(C(t)){e.classList.remove("visible"),s.classList.remove("visible"),n.innerHTML="<kbd>↵</kbd> Go to site",h=[],m=[];return}try{const i=await chrome.history.search({text:t,maxResults:5,startTime:Date.now()-2592e6});i.length>0?(m=i.filter(o=>o.url&&o.title).map(o=>({id:o.id||String(Date.now()),title:o.title||o.url||"",url:o.url||"",domain:E(o.url||""),visitTime:o.lastVisitTime?k(o.lastVisitTime):""})),l.innerHTML=m.map((o,p)=>H(o,p)).join(""),s.classList.add("visible")):(s.classList.remove("visible"),m=[])}catch(i){console.error("Error searching history:",i),s.classList.remove("visible"),m=[]}const u=t.toLowerCase(),b=w.filter(i=>{var o;return i.title.toLowerCase().includes(u)||i.url.toLowerCase().includes(u)||((o=i.searchText)==null?void 0:o.toLowerCase().includes(u))}).slice(0,6);b.length>0?(h=b.map(i=>({id:i.id,title:i.title,url:i.url,favicon:i.favicon,domain:E(i.url),savedAt:k(i.savedAt),topics:y.filter(o=>i.topicIds.includes(o.id)),intents:I.filter(o=>i.intentIds.includes(o.id))})),r.textContent=String(b.length),a.innerHTML=h.map((i,o)=>D(i,o)).join(""),c.style.display="flex",e.classList.add("visible")):(e.classList.remove("visible"),h=[]),m.length>0||h.length>0?n.innerHTML="<kbd>↑</kbd><kbd>↓</kbd> navigate &nbsp; <kbd>↵</kbd> open or Google":n.innerHTML="<kbd>↵</kbd> Google"}function H(t,e){return`
    <div class="newtab-history-item" data-url="${f(t.url)}" data-index="${e}" data-section="history">
      <div class="newtab-history-favicon">
        ${t.domain[0].toUpperCase()}
      </div>
      <div class="newtab-history-content">
        <div class="newtab-history-title">${f(t.title)}</div>
        <div class="newtab-history-meta">
          <span class="newtab-history-domain">${f(t.domain)}</span>
          ${t.visitTime?`<span class="newtab-history-separator">•</span><span class="newtab-history-time">${t.visitTime}</span>`:""}
        </div>
      </div>
    </div>
  `}function D(t,e){const a=t.favicon?`<img src="${f(t.favicon)}" alt="" onerror="this.style.display='none';this.parentElement.textContent='${t.domain[0].toUpperCase()}'">`:t.domain[0].toUpperCase();return`
    <div class="newtab-result-item" data-url="${f(t.url)}" data-index="${e}" data-section="saved">
      <div class="newtab-result-favicon">
        ${a}
      </div>
      <div class="newtab-result-content">
        <div class="newtab-result-title">${f(t.title)}</div>
        <div class="newtab-result-meta">
          <span class="newtab-result-domain">${f(t.domain)}</span>
          <span class="newtab-result-separator">•</span>
          <span class="newtab-result-time">${t.savedAt}</span>
        </div>
      </div>
      <div class="newtab-result-tags">
        ${t.topics.slice(0,2).map(r=>`
          <span class="newtab-result-tag" style="background: ${R(r.color,.15)}; color: ${r.color};">
            ${f(r.name)}
          </span>
        `).join("")}
      </div>
    </div>
  `}function T(t,e,a){var r,c,s,l;if(t.forEach(n=>n.classList.remove("selected")),e.forEach(n=>n.classList.remove("selected")),!(d<0))if(d<a)(r=t[d])==null||r.classList.add("selected"),(c=t[d])==null||c.scrollIntoView({block:"nearest"});else{const n=d-a;(s=e[n])==null||s.classList.add("selected"),(l=e[n])==null||l.scrollIntoView({block:"nearest"})}}function z(){const t=document.getElementById("stat-total"),e=document.getElementById("stat-topics");t.textContent=String(w.length),e.textContent=String(y.length)}function E(t){try{return new URL(t).hostname.replace("www.","")}catch{return t}}function k(t){const e=Math.floor((Date.now()-t)/1e3);if(e<60)return"Just now";const a=Math.floor(e/60);if(a<60)return`${a}m ago`;const r=Math.floor(a/60);if(r<24)return`${r}h ago`;const c=Math.floor(r/24);if(c<7)return`${c}d ago`;const s=Math.floor(c/7);if(s<4)return`${s}w ago`;const l=Math.floor(c/30);return l<12?`${l}mo ago`:`${Math.floor(c/365)}y ago`}function f(t){const e=document.createElement("div");return e.textContent=t,e.innerHTML}function R(t,e){const a=parseInt(t.slice(1,3),16),r=parseInt(t.slice(3,5),16),c=parseInt(t.slice(5,7),16);return`rgba(${a}, ${r}, ${c}, ${e})`}
